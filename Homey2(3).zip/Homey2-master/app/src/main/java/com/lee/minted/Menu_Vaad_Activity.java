package com.lee.minted;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Menu_Vaad_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu__vaad_);
    }
}
